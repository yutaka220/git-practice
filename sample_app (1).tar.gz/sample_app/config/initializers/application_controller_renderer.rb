# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'a8e6047ced849dce8c44bb5dfa83b5d73ca118884649788257a3e6d59733944e7489e94538c1a54e2b809029be8b4fdfe5cd5e2fbd4611d12b9d211d4858345c'
